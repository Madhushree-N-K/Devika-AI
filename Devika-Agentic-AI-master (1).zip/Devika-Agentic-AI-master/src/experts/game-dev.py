"""
RAG for Unity/Godot/Unreal Engine code blocks
"""