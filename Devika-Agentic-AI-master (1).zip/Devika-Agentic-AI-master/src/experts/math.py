"""
Evaluator Function Calling
Wolphram Alpha Plugin
"""